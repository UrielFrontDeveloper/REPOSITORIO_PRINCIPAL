from setuptools import setup, find_packages

setup(
    name="repositorio principal",           # Nombre del paquete
    version="0.1.0",                # Versión
    packages=find_packages(),       # Paquetes a incluir
    description="Un paquete pip simple de saludo",  # Breve descripción
    author="IHKA",         # Tu nombre
    author_email="[urielzft@gmail.com]",  # Tu correo electrónico
    url="https://github.com/urielFrontendDeveloper/REPOSITORIO_PRINCIPAL",     # URL del proyecto
)